package com.etts.etts.student;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.etts.etts.Constant;
import com.etts.etts.DB_Connection;
import com.etts.etts.MainActivity;
import com.etts.etts.R;
import com.etts.etts.admin.GeneTableActivity;
import com.etts.etts.bean.Section;
import com.etts.etts.Util;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class RemoveSchedule extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DB_Connection db = new DB_Connection(this);
    private ArrayList c;
    private ActionBarDrawerToggle mtoggle;
    private DrawerLayout mdrawerlayout;
    List<String> levelNameArray;
    Spinner ScheduleSpinner;
    ArrayAdapter<Section> SectionAdapter;
    String selectedSection;
    int  selectedSectionIndex;
    TextView ScheduleDetials;
    Button RemoveButton;

    ArrayList<Section> sections = new ArrayList<>();

//    ArrayList<String> SectionsArray = new ArrayList<>();

    /////
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mtoggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_schedule);
        RemoveButton = findViewById(R.id.RemoveButton);
        ScheduleSpinner = (Spinner) findViewById(R.id.ScheduleSpinner);


        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("operation", "getssection");
        params.put("student", Constant.user_name);
        asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                Util.dismissprogress();

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                Util.dismissprogress();
                Log.e("salama", "onSuccess: " + responseString);
                try {
                    sections = new ArrayList<>();
                    JSONObject jsonObject = new JSONObject(responseString);
                    if (!jsonObject.getBoolean("error")) {
                        JSONArray jsonObject1 = jsonObject.getJSONArray("message");
                        int n = jsonObject1.length();
                        for (int i = 0; i < n; i++) {
                            // GET INDIVIDUAL JSON OBJECT FROM JSON ARRAY
                            Section section_obj = new Section();
                            JSONArray jsonArray = jsonObject1.getJSONArray(i);

                            section_obj.setId(jsonArray.get(0) + "");
                            section_obj.setSection_name(jsonArray.get(1) + "");
                            section_obj.setDays(jsonArray.get(3) + "");
                            section_obj.setSection_time(jsonArray.get(4) + "");

                            sections.add(section_obj);
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                SectionAdapter = new ArrayAdapter<Section>(RemoveSchedule.this, android.R.layout.simple_spinner_item, sections);
                SectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
                ScheduleSpinner.setAdapter(SectionAdapter);
            }


        });


        mdrawerlayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        ScheduleDetials = ((TextView) findViewById(R.id.ScheduleDetials));

        ScheduleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                Section section = sections.get(i);
                ScheduleDetials .setText(section.getDays() + "\n" + section.getSection_time());
                selectedSection = "" + section.getId();
                selectedSectionIndex=i;
                //section_obj.setSection_time(Section_time);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                ScheduleDetials.setText("");
                selectedSection="";
                selectedSectionIndex=-1;
                ScheduleSpinner.setSelection(0);
            }
        });

        RemoveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                RequestParams params = new RequestParams();
                params.put("operation", "deletessection");
                params.put("student", Constant.user_name);
                params.put("section", selectedSection);
                if (selectedSection != null && !selectedSection.isEmpty()) {
                    asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                            Util.dismissprogress();
                            Toast.makeText(RemoveSchedule.this, "error", Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            sections.remove(selectedSectionIndex);
                            selectedSectionIndex=-1;
                            ScheduleDetials.setText("");
                            SectionAdapter = new ArrayAdapter<Section>(RemoveSchedule.this, android.R.layout.simple_spinner_item, sections);
                            SectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
                            ScheduleSpinner.setAdapter(SectionAdapter);
                            Util.dismissprogress();
                            Toast.makeText(RemoveSchedule.this, "Removed ", Toast.LENGTH_SHORT).show();
                        }


                    });
                } else {
                    Toast.makeText(RemoveSchedule.this, "Select Section first", Toast.LENGTH_SHORT).show();
                }


            }
        });




        //menu
        mtoggle = new ActionBarDrawerToggle(this, mdrawerlayout, R.string.open, R.string.close);
        mdrawerlayout.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(this);





    }



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add) {
            Intent intent1 = new Intent(this, AddSchedule.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.edit) {
            Intent intent1 = new Intent(this, RemoveSchedule.class);
            intent1.putExtra("update", true);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.annou) {
            Intent intent1 = new Intent(this, AnnListActivity.class);
            this.startActivity(intent1);
            return true;
        }if (id == R.id.gen) {
            GeneTableActivity.admin=0;
            Intent intent1 = new Intent(this, GeneTableActivity.class);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.logout) {
            Intent intent1 = new Intent(this, MainActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        return false;
    }
}
