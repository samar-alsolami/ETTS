package com.etts.etts.admin;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.etts.etts.Constant;
import com.etts.etts.DB_Connection;
import com.etts.etts.LoginActivity;
import com.etts.etts.MainActivity;
import com.etts.etts.R;
import com.etts.etts.bean.Section;
import com.etts.etts.Util;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class SemesterInformation extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DB_Connection db = new DB_Connection(this);
    Section section_obj = new Section();

    private DrawerLayout mdrawerlayout;
    private ActionBarDrawerToggle mtoggle;
    NavigationView navigationView;
    static int id;
    Button addSectionButton, searchSectionButton, deleteCourseButton;
    Button addCourseButton;
    TextView txtcourse;
    EditText Section_name;
    Spinner DaysSpinner;
    //level spinner
    Spinner levelSpinner;
    //time
    Spinner TimeSpinner;

    List<String> levelNameArray;
    List<String> TimeArray, DaysArray;
    ArrayList<String> courses = new ArrayList<>();
    ArrayAdapter<String> levelAdapter;

    /////
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mtoggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semester_information);
        mdrawerlayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        addSectionButton = (Button) findViewById(R.id.AddSectionButton);
        searchSectionButton = (Button) findViewById(R.id.searchSectionButton);
        addCourseButton = (Button) findViewById(R.id.NextCourseButton);
        deleteCourseButton = (Button) findViewById(R.id.deleteCourseButton);
        txtcourse = (TextView) findViewById(R.id.CourseName);
        Section_name = (EditText) findViewById(R.id.SectionName);
        levelSpinner = (Spinner) findViewById(R.id.LevelSpinner);
        TimeSpinner = (Spinner) findViewById(R.id.TimeSpinner);
        DaysSpinner = (Spinner) findViewById(R.id.DaysSpinner);

        if (getIntent() != null) {
            Boolean aBoolean = getIntent().getBooleanExtra("update", false);
            if (aBoolean) {
                TimeSpinner.setEnabled(false);
                DaysSpinner.setEnabled(false);
                searchSectionButton.setVisibility(View.VISIBLE);

            }
        }
//menu
        mtoggle = new ActionBarDrawerToggle(this, mdrawerlayout, R.string.open, R.string.close);
        mdrawerlayout.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(this);
/////


        deleteCourseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                RequestParams params = new RequestParams();
                params.put("operation", "deletesection");
                params.put("id", section_obj.getId());
                Util.showprogress(SemesterInformation.this, "Deleting Section");
                asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                    @Override
                    public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                        Util.dismissprogress();
                    }

                    @Override
                    public void onSuccess(int statusCode, Header[] headers, String responseString) {
                        Section_name.setText("");
                        TimeSpinner.setSelection(0);
                        DaysSpinner.setSelection(0);
                        TimeSpinner.setEnabled(false);
                        DaysSpinner.setEnabled(false);
                        searchSectionButton.setVisibility(View.VISIBLE);
                        deleteCourseButton.setVisibility(View.GONE);
                        Util.dismissprogress();
                    }


                });

                Util.dismissprogress();
            }
        });

        searchSectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Section_name.getText() == null || (Section_name.getText() + "").isEmpty() || txtcourse.getText() == null || txtcourse.getText().toString().isEmpty()) {
                    Toast.makeText(SemesterInformation.this, "Please complete all Fields", Toast.LENGTH_SHORT).show();

                } else {
                    AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                    RequestParams params = new RequestParams();
                    params.put("operation", "getsection");
                    params.put("section", Section_name.getText().toString());
                    params.put("course", txtcourse.getText().toString());
                    Util.showprogress(SemesterInformation.this, "Searching about Section ...");
                    asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                            Util.dismissprogress();
                            Toast.makeText(SemesterInformation.this, "Section not found", Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            Util.dismissprogress();
                            try {
                                Log.e("SSSSSS", "onSuccess: " + responseString);
                                JSONObject jsonObject = new JSONObject(responseString);
                                if (!jsonObject.getBoolean("error")) {
                                    JSONObject jsonObject1 = jsonObject.getJSONObject("message");
                                    section_obj.setId(jsonObject1.getInt("Id") + "");
                                    section_obj.setDays(jsonObject1.getString("SectionDate"));
                                    section_obj.setSection_time(jsonObject1.getString("SectionTime"));
                                    searchSectionButton.setVisibility(View.GONE);
                                    TimeSpinner.setSelection(TimeArray.indexOf(section_obj.getSection_time()));
                                    DaysSpinner.setSelection(DaysArray.indexOf(section_obj.getDays()));
                                    TimeSpinner.setEnabled(true);
                                    DaysSpinner.setEnabled(true);
                                    addSectionButton.setText("\tUpdate Section\t");
                                    deleteCourseButton.setVisibility(View.VISIBLE);
                                } else {
                                    Toast.makeText(SemesterInformation.this, "Section not found", Toast.LENGTH_SHORT).show();

                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }


                    });

                    Util.dismissprogress();
                }
            }
        });


        addSectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Section_name.getText() == null || (Section_name.getText() + "").isEmpty() || txtcourse.getText() == null || txtcourse.getText().toString().isEmpty()
                        || DaysSpinner.getSelectedItemPosition() == 0 || TimeSpinner.getSelectedItemPosition() == 0) {
                    Toast.makeText(SemesterInformation.this, "Please complete all Selections", Toast.LENGTH_SHORT).show();
                } else {
                    AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                    RequestParams params = new RequestParams();
                    if (addSectionButton.getText().toString().equals("\tUpdate Section\t")) {
                        params.put("operation", "updatesection");
                        params.put("id", section_obj.getId());
                        params.put("sectionNumber", section_obj.getNumber() + "");

                    } else {
                        params.put("operation", "addsection");

                    }
                    params.put("section", Section_name.getText().toString());
                    params.put("course", txtcourse.getText().toString());

                    params.put("sectiondate", section_obj.getDays());
                    params.put("sectiontime", section_obj.getSection_time());
                    Util.showprogress(SemesterInformation.this, "Adding Section");
                    asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                            Util.dismissprogress();
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            Log.e("AAAAASASS", "onSuccess: " + responseString);
                            Section_name.setText("");
                            TimeSpinner.setSelection(0);
                            DaysSpinner.setSelection(0);
                           // searchSectionButton.setVisibility(View.VISIBLE);
                           // deleteCourseButton.setVisibility(View.GONE);
                            Util.dismissprogress();
                        }


                    });

                    Util.dismissprogress();
                }
            }
        });
        addCourseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getNext();
            }
        });
///
        //level spinner
        levelNameArray = new ArrayList<String>();
        levelNameArray.add("Select Level");
        levelNameArray.add("0");
        levelNameArray.add("3");
        levelNameArray.add("4");
        levelNameArray.add("5");
        levelNameArray.add("6");
        levelNameArray.add("7");
        levelNameArray.add("8");
        levelNameArray.add("9");
        levelNameArray.add("10");

        levelAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, levelNameArray);
        levelAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        levelSpinner.setAdapter(levelAdapter);
        levelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("SAlama", "onItemSelected: ");
                String level = levelNameArray.get(i);
                if (i != 0) {


                    section_obj.setLevel(level);


                    AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                    RequestParams params = new RequestParams();
                    params.put("operation", "courses");
                    params.put("level", level);
                    courses = new ArrayList<>();
                    Util.showprogress(SemesterInformation.this, "loading Courses");
                    asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                            Util.dismissprogress();
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            JSONArray joRespond = null;
                            id = 0;
                            try {
                                joRespond = new JSONArray(responseString);

                                int n = joRespond.length();
                                for (int i = 0; i < n; i++) {
                                    // GET INDIVIDUAL JSON OBJECT FROM JSON ARRAY
                                    JSONObject jo = joRespond.getJSONObject(i);
                                    courses.add(jo.getString("Course_id"));
                                }
                                if (!courses.isEmpty())
                                    txtcourse.setText(courses.get(id));
                                Util.dismissprogress();
                            } catch (Exception e) {
                                Util.dismissprogress();
                                e.printStackTrace();
                            }
                        }


                    });

                    Util.dismissprogress();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

                levelSpinner.setSelection(0);
            }
        });

        TimeArray = new ArrayList<String>();
        TimeArray.add("Select Time");
        TimeArray.add("8:00 - 8:50");
        TimeArray.add("9:00 - 9:50");
        TimeArray.add("10:00 - 10:50");
        TimeArray.add("11:00 - 11:50");
        TimeArray.add("12:00 - 12:50");
        TimeArray.add("13:00 - 13:50");
        TimeArray.add("14:00 - 14:50");
        TimeArray.add("8:00 - 9:20");
        TimeArray.add("9:30 - 10:50");
        TimeArray.add("11:00 - 12:20");
        TimeArray.add("12:30 - 13:50");
        TimeArray.add("14:00 - 15:20");
        TimeArray.add("8:00 - 9:50");
        TimeArray.add("9:00 - 10:50");
        TimeArray.add("10:00 - 11:50");
        TimeArray.add("12:00 - 13:50");
        TimeArray.add("13:00 - 14:50");

        ArrayAdapter<String> TimeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, TimeArray);

        TimeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        TimeSpinner.setAdapter(TimeAdapter);
        TimeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String Section_time = TimeArray.get(i);
                section_obj.setSection_time(Section_time);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

                TimeSpinner.setSelection(0);
            }
        });

        DaysArray = new ArrayList<String>();
        DaysArray.add("Select Days");
        DaysArray.add("U, T, R");
        DaysArray.add("U, T");
        DaysArray.add("U, R");
        DaysArray.add("T, R");
        DaysArray.add("M, W");
        DaysArray.add("U");
        DaysArray.add("T");
        DaysArray.add("R");

        ArrayAdapter<String> DaysAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, DaysArray);


        DaysAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        DaysSpinner.setAdapter(DaysAdapter);
        DaysSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String Section_days = DaysArray.get(i);
                section_obj.setDays(Section_days);

                if (i == 1) {
                    section_obj.setDays_num(3);
                } else if (i == 2 || i == 3 || i == 4 || i == 5) {
                    section_obj.setDays_num(2);
                } else if (i == 6 || i == 7 || i == 8) {
                    section_obj.setDays_num(1);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

                DaysSpinner.setSelection(0);
            }
        });

        txtcourse.setText("");
        TimeSpinner.setSelection(0);
        DaysSpinner.setSelection(0);
    }


    public void back_to_login(View v) {
        ImageButton button2 = (ImageButton) v;
        startActivity(new Intent(SemesterInformation.this, LoginActivity.class));
    }

    public void add_section(View v) {

        db.insertSection(section_obj);
    }

    public void nextCourse(View v) {

        db.insertSection(section_obj);
    }

    //for menu
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.edit) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.putExtra("update", true);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.annou) {
            Intent intent1 = new Intent(this, AnnActivity.class);
            this.startActivity(intent1);
            return true;
        }

        if (id == R.id.exam) {
            Intent intent1 = new Intent(this, FinalExamActivity.class);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.gen) {
            GeneTableActivity.admin=1;
            AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
            RequestParams params = new RequestParams();
            asyncHttpClient.post(Constant.GENERATE, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            Intent intent1 = new Intent(SemesterInformation.this, GeneTableActivity.class);
                            SemesterInformation.this.startActivity(intent1);

                        }
                    }
            );
            return true;
        }
        if (id == R.id.logout) {
            Intent intent1 = new Intent(this, MainActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        return false;
    }

    public void getNext() {
        id++;
        if (id < courses.size()) {
            txtcourse.setText(courses.get(id));
            Section_name.setText("");
            TimeSpinner.setSelection(0);
            DaysSpinner.setSelection(0);
        } else {
            Toast.makeText(SemesterInformation.this, "End of courses", Toast.LENGTH_SHORT).show();
        }
    }
}
