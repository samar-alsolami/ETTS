package com.etts.etts.admin;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.etts.etts.Constant;
import com.etts.etts.MainActivity;
import com.etts.etts.R;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import cz.msebera.android.httpclient.Header;

public class FinalExamActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout mdrawerlayout;
    private ActionBarDrawerToggle mtoggle;
    NavigationView navigationView;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    Button next_final;
    EditText strat_date, end_date;
    public static Date start, end;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_exam);
        strat_date = findViewById(R.id.strat_date);
        end_date = findViewById(R.id.end_date);

        final ImageView iconeDate_end = (ImageView) findViewById(R.id.icon_date_end);
        iconeDate_end.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                birthDateDialog(1, end_date, iconeDate_end);
            }
        });

        end_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                birthDateDialog(1, end_date, iconeDate_end);
            }
        });


        final ImageView iconeDate_start = (ImageView) findViewById(R.id.icon_date_start);
        iconeDate_start.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                birthDateDialog(0, strat_date, iconeDate_start);
            }
        });

        strat_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                birthDateDialog(0, strat_date, iconeDate_start);
            }
        });

        mdrawerlayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        navigationView = (NavigationView) findViewById(R.id.navigation);
        next_final = findViewById(R.id.next_final);
        next_final.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(start!=null&& end!=null) {
                    Constant.MaxNumber=0;
                    Intent intent1 = new Intent(FinalExamActivity.this, TableActivity.class);
                    startActivity(intent1);
                }else{
                    Toast.makeText(FinalExamActivity.this,"PLease Enter Dates First  ",Toast.LENGTH_SHORT).show();

                }
            }
        });

        mtoggle = new ActionBarDrawerToggle(this, mdrawerlayout, R.string.open, R.string.close);
        mdrawerlayout.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mtoggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.edit) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.putExtra("update", true);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.annou) {
            Intent intent1 = new Intent(this, AnnActivity.class);
            this.startActivity(intent1);
            return true;
        }

        if (id == R.id.exam) {
            Intent intent1 = new Intent(this, FinalExamActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if(id==R.id.gen){
            GeneTableActivity.admin=1;
            AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
            RequestParams params = new RequestParams();
            asyncHttpClient.post(Constant.GENERATE, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            Intent intent1 = new Intent(FinalExamActivity.this, GeneTableActivity.class);
                            FinalExamActivity.this.startActivity(intent1);

                        }
                    }
            );
            return true;
        }
        if (id == R.id.logout) {
            Intent intent1 = new Intent(this, MainActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        return false;
    }

    public void birthDateDialog(final int se, final EditText editText, View view) {
        view.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        FinalExamActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth, mDateSetListener, year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth();
                int year =  datePicker.getYear();

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);



//                Log.v(TAG, "onDateSet: date: " + birthDay + "/" + birthMonth + "/" + birthYear);
                editText.setText(new SimpleDateFormat("dd/MM/yyyy").format(calendar.getTime()));
                if (se == 0) {
                    start = calendar.getTime();
                } else {
                    end   = calendar.getTime();
                    if (start.after(end)){
                        editText.setText("");
                        end=null;
                        Toast.makeText(FinalExamActivity.this,"PLease Select Date after Start Date ",Toast.LENGTH_SHORT).show();
                    }

                }

            }

        };
    }
}
