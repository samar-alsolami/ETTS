package com.etts.etts;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.etts.etts.bean.Section;
import com.etts.etts.bean.users_account;

import java.util.ArrayList;

//import com.sun.org.apache.bcel.internal.generic.Select;

public class DB_Connection extends SQLiteOpenHelper{
    SQLiteDatabase db ;
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "etts_db";
    final Section section_obj=new Section();


    public DB_Connection(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //create user_account table
        String CREATE_usersAccount_TABLE = "CREATE TABLE IF NOT EXISTS UsersAccount ( Id INTEGER PRIMARY KEY, Email TEXT, Password TEXT)";
        //create courses table
        String CREATE_Courses_TABLE = "CREATE TABLE IF NOT EXISTS Courses ( Course_id TEXT PRIMARY KEY, Level INTEGER, Section_num INTEGER ) " ;

        //create section table
        String CREATE_Section_TABLE = "CREATE TABLE IF NOT EXISTS Section ( Section_name TEXT ,Course_id TEXT, Days TEXT, number_of_days INTEGER , Times TEXT , PRIMARY KEY(Section_name,Course_id), FOREIGN KEY (Course_id) REFERENCES Courses(Course_id)  ) " ;
        //create student_schedule
        String CREATE_Student_Schedule_TABLE=" CREATE TABLE IF NOT EXISTS Student_Schedule ( Student_Id INTEGER PRIMARY KEY, Level INTEGER, Courses TEXT, Num_of_Courses INTEGER,FOREIGN KEY (Student_Id) REFERENCES UsersAccount(Id),FOREIGN KEY (Level) REFERENCES Courses(Level))";

        Log.d("myTag", "M1");
        //execute statments for tables....
        try
        {
            Log.d("myTag", "M2");
            db.execSQL(CREATE_usersAccount_TABLE);

            db.execSQL(CREATE_Courses_TABLE);
            db.execSQL(CREATE_Section_TABLE);
            db.execSQL(CREATE_Student_Schedule_TABLE);
        }

            catch (SQLException e) {
            Log.d("myTag",e.getMessage());

            e.printStackTrace();
        }
        Log.d("myTag", "M3");
        inset_Courses_2();
    }
    //method to insert account
    public void insertaccount(users_account u){
        db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("Id",u.getId());
        values.put("Email",u.getEmail());
        values.put("Password",u.getPassword());
        db.insert("UsersAccount",null,values);
        db.close();
    }
    //method to search password
    public String searchpass(String Id){
        try {

            Log.d("my2Tag", "M2");
            SQLiteDatabase     db2=this.getWritableDatabase();
            String query="select Password from UsersAccount where Email=\""+Id+"\"";



            Cursor cursor=db2.rawQuery(query,null);
            Log.d("my2Tag", "M3");
            String b="";
            if (cursor.moveToNext()) {
               b=  cursor.getString(0);
            }
            Log.d("my2Tag", b);
            cursor.close();
            db2.close();

            return b;
        } catch (Exception e) {
            Log.d("my2Tag", e.getMessage());
        }
        return "not fornf";
    }
    ///////////////////////////////
    // method for insert courses
    public void insertCourses(String name, int level){

        try {
            db=this.getWritableDatabase();
            ContentValues values=new ContentValues();
            values.put("Course_id",name);
            values.put("Level",level);
            db.insert("Courses",null,values);
            db.close();
        } catch (Exception e) {
            Log.d("my2Tag", "I6");
        }
    }
    /////////////////////////////
    //method for write all courses in course table by using insertCourses method
    public void inset_Courses_2(){







    }
    /////////////////////
    //method for adding number of sections for courses
    public void add_section_number(String course_id , int section_num){
        //insert into Courses (Section_num) values(section_num) where Course_id= course_id;
        db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("Section_num",section_num);

        db.insert("Courses",course_id,values);
        db.close();
    }
    /////////////////////
    //insert section Information in Section table
    public void insertSection(Section section_obj){
        db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("Course_id",section_obj.getCourse_id());
        values.put("Level",section_obj.getLevel());
        values.put("Section_name",section_obj.getSection_name());
        values.put("Days",section_obj.getDays());
        values.put("time",section_obj.getSection_time());
        values.put("number_of_days",section_obj.getDays_num());

        db.insert("Section",null,values);
    db.close();
    }
    /////////////////////
    //get courses names for each level
    public ArrayList getcoursesbylevel(int level){
        ArrayList array_List=new ArrayList();
        // int level_number = (Integer.parseInt(level));
        db=this.getReadableDatabase();
        Cursor res =db.rawQuery("select * from Courses where Level = "+level,null);
        while(res.moveToNext()) {
            array_List.add(res.getString(0));
        }
        db.close();
        return array_List;

    }
    //////////////////
    //get other courses that are not in student level
    public ArrayList getOtherCorses(int level){
        try {  ArrayList array_List=new ArrayList();

          db = this.getReadableDatabase();
          Cursor res = db.rawQuery("select * from Courses where Level != " + level + "&& Section_num >=1", null);
          Log.d("my4Tag", res.getCount() + "");

          while (res.moveToNext()) {
              array_List.add(res.getString(0));
          }
          db.close();
          return array_List;
      }
      catch (Exception e)
      {
          Log.d("my4Tag", e.getMessage());

      }

return null;
      }

    //method for section spinner on edit course page
    public ArrayList SectionSpinner(String course_id){
        db=this.getReadableDatabase();
        ArrayList section_Array=new ArrayList();

        Cursor res =db.rawQuery("select Section_name from Section where Course_id = \""+course_id +"\"" ,null);
        res.moveToFirst();
        while(res.moveToNext()) {
            section_Array.add(res.getString(0));
        }
        db.close();
        return section_Array;
    }
    //method for admin to update section information
    public void UpdateSecion(Section section_obj){
        db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("Times",section_obj.getSection_time());
        values.put("Days",section_obj.getDays());
        values.put("number_of_days",section_obj.getSection_name());


        db.update("Section",values,"Section_name=?, Course_id=?",new String[]{section_obj.getSection_name(),section_obj.getCourse_id()});
        db.close();
    }
    //method for admin to drop section
    public void DropSection(Section section_obj){
        db=this.getWritableDatabase();
        ContentValues values=new ContentValues();

        db.delete("Section","Section_name=?,  Course_id=?",new String[]{section_obj.getSection_name(),section_obj.getCourse_id()});
        db.close();
    }
    //seach course for admin in edit course page
    public ArrayList<String> searchMethod( String course){

        //  db.execSQL("Select Course_id from Section where Course_id like '"+course+"%'");

        ArrayList<String> searchArray=new ArrayList();

        Cursor res =db.rawQuery("Select * from Section where Course_id like '"+course+"%'" ,null);
        res.moveToFirst();
        while(res.moveToNext()) {
            searchArray.add(res.getString(0));
        }
        db.close();
        return searchArray;
    }
    public ArrayList getAllCorses(){
        ArrayList array_List=new ArrayList();
        Log.d("my4Tag", array_List.isEmpty()+"hhhhhh");
        db=this.getReadableDatabase();
        Cursor res =db.rawQuery("select * from Courses  ",null);
        Log.d("my4Tag", res.getCount()+"       PPPPPPPP");
        res.moveToFirst();
        while(res.moveToNext()) {
            array_List.add(res.getString(0));
        }
        db.close();
        Log.d("my4Tag", array_List.isEmpty()+"hhhhhh");
        return array_List;
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
// Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS UsersAccount");
        db.execSQL("DROP TABLE IF EXISTS Courses");
        db.execSQL("DROP TABLE IF EXISTS Section");
        db.execSQL("DROP TABLE IF EXISTS Student_Schedule");

// Creating tables again
        onCreate(db);
    }

}
