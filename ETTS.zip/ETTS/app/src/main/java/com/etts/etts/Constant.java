package com.etts.etts;

/**
 * Created by ahmedsalamamohamed on 3/16/18.
 */

public class Constant {
    public static final String HOME="http://care-of-me.com/etts/var/www/etts/index.php";
    public static final String GENERATE="http://care-of-me.com/etts/var/www/etts/generate.php";
    public static String user_name;
    public static String email;
    public static int MaxNumber;
}
