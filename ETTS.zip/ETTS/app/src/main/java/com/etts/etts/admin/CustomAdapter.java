package com.etts.etts.admin;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.etts.etts.Constant;
import com.etts.etts.R;
import com.etts.etts.Util;
import com.etts.etts.bean.Section;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

/**
 * Created by ahmedsalamamohamed on 3/30/18.
 */

public class CustomAdapter extends ArrayAdapter<Section> implements View.OnClickListener {
    private String m_Text = "";
    private ArrayList<Section> dataSet;
    Context mContext;
    private int lastPosition = -1;

    // View lookup cache
    private static class ViewHolder {
        LinearLayout section;
        TextView section_name;
        TextView number;
        TextView days;
        TextView times;
    }

    public CustomAdapter(ArrayList<Section> data, Context context) {
        super(context, R.layout.exam_row_layout, data);
        this.dataSet = data;
        this.mContext = context;

    }

    @Override
    public void onClick(View v) {


        final Section dataModel = (Section) v.getTag();

        Log.e("asswe", "onClick: " + dataModel.getSection_name());
        final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle("Enter Period Number:(Up to " + Constant.MaxNumber + ")");

// Set up the input
        final EditText input = new EditText(mContext);
// Specify the type of input expected; this, for example, sets the input as a number, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        builder.setView(input);

// Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                m_Text = input.getText().toString();
                if (m_Text != null && !m_Text.isEmpty()) {
                    int num = Integer.parseInt(m_Text);
                    if (num > 0 && num <= Constant.MaxNumber) {
                        dataModel.setNumber(num + "");


                        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                        RequestParams params = new RequestParams();
                        Log.e("Asser", "onFailure: "+dataModel.getId()+"-"+num +"-"+dataModel.getCourse_id()+"-"+dataModel.getDays()+"-"+dataModel.getSection_time()+"-");
                        params.put("operation", "updatesection");
                        params.put("id", dataModel.getId());
                        params.put("sectionNumber", num+"");

                        params.put("section", dataModel.getSection_name()+"nnn");
                        params.put("course", dataModel.getCourse_id());

                        params.put("sectiondate", dataModel.getDays());
                        params.put("sectiontime", dataModel.getSection_time());
                        asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                            @Override
                            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                                Log.e("Asser", "onFailure: "+responseString );
                            }

                            @Override
                            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                                Log.e("Asser", "onSuccess: "+responseString );
                            }


                        });


                        notifyDataSetChanged();
                    } else {
                        Toast.makeText(mContext, "Please Enter Valid Number", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();


    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Section dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {

            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.exam_row_layout, parent, false);
            viewHolder.section = (LinearLayout) convertView.findViewById(R.id.section);
            viewHolder.section_name = (TextView) convertView.findViewById(R.id.section_name);
            viewHolder.number = (TextView) convertView.findViewById(R.id.number);
            viewHolder.days = (TextView) convertView.findViewById(R.id.days);
            viewHolder.times = (TextView) convertView.findViewById(R.id.times);

            result = convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }


        lastPosition = position;

        viewHolder.section_name.setText(dataModel.getSection_name()+" ( "+dataModel.getCourse_id()+" )");
        viewHolder.times.setText(dataModel.getSection_time());
        viewHolder.days.setText(dataModel.getDays());
        viewHolder.number.setText(dataModel.getNumber() + "");

        viewHolder.section.setOnClickListener(this);
        viewHolder.section.setTag(dataModel);
        // Return the completed view to render on screen
        return convertView;
    }
}