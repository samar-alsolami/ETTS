package com.etts.etts.admin;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.etts.etts.Constant;
import com.etts.etts.MainActivity;
import com.etts.etts.R;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

import cz.msebera.android.httpclient.Header;

public class TableActivity extends AppCompatActivity  {

    TableLayout table;
    Button back, next;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
        table = (TableLayout) findViewById(R.id.table);
        table.setGravity(Gravity.CENTER);
        table.setWeightSum(4);
        back = (Button) findViewById(R.id.back);
        next = findViewById(R.id.next);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(TableActivity.this, FinalExamActivity.class);
                startActivity(intent1);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(TableActivity.this, SectionETActivity.class);
                startActivity(intent1);
            }
        });


        TableRow tr_head = new TableRow(this);

        tr_head.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT
        ));

        TextView textArray = new TextView(this);
        textArray.setText("    \n");
        
        textArray.setTextColor(Color.BLACK);
        textArray.setTextSize(20);
        textArray.setPadding(50, 5, 50, 5);
        textArray.setBackgroundResource(R.drawable.cell_shape);
        tr_head.addView(textArray);

        TextView textArray1 = new TextView(this);
        textArray1.setText("S1\n");
        textArray1.setGravity(Gravity.CENTER);
        textArray1.setTextSize(20);
        textArray1.setTextColor(Color.BLACK);
        textArray1.setBackgroundResource(R.drawable.cell_shape);
        textArray1.setPadding(50, 5, 50, 5);
        tr_head.addView(textArray1);

        TextView textArray2 = new TextView(this);
        textArray2.setText("S2\n");
        textArray2.setTextColor(Color.BLACK);
        textArray2.setTextSize(20);
        textArray2.setPadding(50, 5, 50, 5);
        textArray2.setBackgroundResource(R.drawable.cell_shape);
        tr_head.addView(textArray2);

        TextView textArray3 = new TextView(this);
        textArray3.setText("S3\n");
        textArray3.setTextColor(Color.BLACK);
        textArray3.setTextSize(20);
        textArray3.setPadding(50, 5, 50, 5);
        textArray3.setBackgroundResource(R.drawable.cell_shape);
        tr_head.addView(textArray3);


        table.addView(tr_head);


        SimpleDateFormat outFormat_day = new SimpleDateFormat("EEEE");
        SimpleDateFormat outFormat = new SimpleDateFormat("dd/MM");

        Calendar calendar_start = Calendar.getInstance();
        calendar_start.setTime(FinalExamActivity.start);
        Calendar calendar_end = Calendar.getInstance();
        calendar_end.setTime(FinalExamActivity.end);

        int Values = 0;
        while (calendar_start.before(calendar_end)) {
            Date date = calendar_start.getTime();
            Log.e("ASSSSER", "onCreate: " + outFormat.format(date));
            String day = outFormat_day.format(date);
            if (!"Friday".equals(day) && !"Saturday".equals(day)) {

                TableRow tableRow = new TableRow(this);

                tableRow.setLayoutParams(new TableRow.LayoutParams(
                        TableRow.LayoutParams.WRAP_CONTENT,
                        TableRow.LayoutParams.WRAP_CONTENT
                ));

                TextView textArrayRow = new TextView(this);
                textArrayRow.setText(day + "\n" + outFormat.format(date));
                textArrayRow.setTextColor(Color.BLACK);
                textArrayRow.setTextSize(20);
                textArrayRow.setPadding(50, 5, 50, 5);
                textArrayRow.setBackgroundResource(R.drawable.cell_shape);
                tableRow.addView(textArrayRow);

                TextView textArray1Row = new TextView(this);
                textArray1Row.setText((Values + 1)+"\n");
                textArray1Row.setGravity(Gravity.CENTER);
                textArray1Row.setTextSize(20);
                textArray1Row.setTextColor(Color.BLACK);
                textArray1Row.setBackgroundResource(R.drawable.cell_shape);
                textArray1Row.setPadding(50, 5, 50, 5);
                tableRow.addView(textArray1Row);

                TextView textArray2Row = new TextView(this);
                textArray2Row.setText((Values + 2)+"\n");
                textArray2Row.setTextColor(Color.BLACK);
                textArray2Row.setTextSize(20);
                textArray2Row.setPadding(50, 5, 50, 5);
                textArray2Row.setBackgroundResource(R.drawable.cell_shape);
                tableRow.addView(textArray2Row);

                TextView textArray3Row = new TextView(this);
                textArray3Row.setText((Values + 3)+"\n");
                textArray3Row.setTextColor(Color.BLACK);
                textArray3Row.setTextSize(20);
                textArray3Row.setPadding(50, 5, 50, 5);
                textArray3Row.setBackgroundResource(R.drawable.cell_shape);
                tableRow.addView(textArray3Row);


                table.addView(tableRow);
                Values+=3;
                Constant.MaxNumber+=3;


            }
            calendar_start.add(Calendar.DATE, 1);
        }


    }



}
