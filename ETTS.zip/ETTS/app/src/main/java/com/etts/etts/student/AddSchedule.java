package com.etts.etts.student;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.etts.etts.Constant;
import com.etts.etts.DB_Connection;
import com.etts.etts.LoginActivity;
import com.etts.etts.MainActivity;
import com.etts.etts.R;
import com.etts.etts.admin.GeneTableActivity;
import com.etts.etts.admin.SemesterInformation;
import com.etts.etts.bean.Section;
import com.etts.etts.Util;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class AddSchedule extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DB_Connection db = new DB_Connection(this);
    private ArrayList c;
    private ActionBarDrawerToggle mtoggle;
    private DrawerLayout mdrawerlayout;
    TextView course;
    ArrayList<String> courses = new ArrayList<>();
    List<String> levelNameArray;
    Spinner levelSpinner;
    Spinner CoursesSpinner;
    ArrayAdapter<Section> SectionAdapter;
    Spinner SectionSpinner;
    ArrayAdapter<String> CoursesAdapter;
    String selectedSection;
    TextView textView;
    Button AddButton;

    ArrayList<Section> sections = new ArrayList<>();

//    ArrayList<String> SectionsArray = new ArrayList<>();

    /////
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mtoggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_schedule);
        AddButton=findViewById(R.id.AddButton);
        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                RequestParams params = new RequestParams();
                params.put("operation", "addssection");
                params.put("student", Constant.user_name);
                params.put("section",selectedSection);
                if(selectedSection!=null&& !selectedSection.isEmpty()){
                    asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                            Util.dismissprogress();
                            Toast.makeText(AddSchedule.this, "error", Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {

                            Util.dismissprogress();
                            Toast.makeText(AddSchedule.this, "added ", Toast.LENGTH_SHORT).show();
                        }


                    });
                }else{
                    Toast.makeText(AddSchedule.this, "Select Section first", Toast.LENGTH_SHORT).show();
                }


            }
        });
        mdrawerlayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        CoursesSpinner = (Spinner) findViewById(R.id.CoursesSpinner);
textView=((TextView) findViewById(R.id.sectionInfo));
        courses.add("Select Course");
        CoursesAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, courses);
        CoursesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        CoursesSpinner.setAdapter(CoursesAdapter);


        SectionSpinner = (Spinner) findViewById(R.id.Section_Spinner);
        SectionAdapter = new ArrayAdapter<Section>(this, android.R.layout.simple_spinner_item, sections);
        SectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        SectionSpinner.setAdapter(SectionAdapter);

        //menu
        mtoggle = new ActionBarDrawerToggle(this, mdrawerlayout, R.string.open, R.string.close);
        mdrawerlayout.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(this);

        course = (TextView) findViewById(R.id.CourseName);
        try {

            //level spinner
            Log.d("my4Tag", "hhhhhh");
            levelSpinner = (Spinner) findViewById(R.id.LevelSpinner);

            levelNameArray = new ArrayList<String>();
            levelNameArray.add("Select Level");
            levelNameArray.add("Level 0");
            levelNameArray.add("Level 3");
            levelNameArray.add("Level 4");
            levelNameArray.add("Level 5");
            levelNameArray.add("Level 6");
            levelNameArray.add("Level 7");
            levelNameArray.add("Level 8");
            levelNameArray.add("Level 9");
            levelNameArray.add("Level 10");


            ArrayAdapter<String> levelAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, levelNameArray);
            levelAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
            levelSpinner.setAdapter(levelAdapter);
            levelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    Log.e("SAlama", "onItemSelected: ");

                    if (i != 0) {
                        String level = levelNameArray.get(i).split(" ")[1];


                        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                        RequestParams params = new RequestParams();
                        params.put("operation", "courses");
                        params.put("level", level);
                        courses = new ArrayList<>();
                        courses.add("Select Course");
                        Util.showprogress(AddSchedule.this, "loading Courses");
                        asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                            @Override
                            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                                Util.dismissprogress();
                            }

                            @Override
                            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                                JSONArray joRespond = null;
                                try {
                                    courses=new ArrayList<>();
                                    courses.add("Select Course");
                                    joRespond = new JSONArray(responseString);

                                    int n = joRespond.length();
                                    for (int i = 0; i < n; i++) {
                                        // GET INDIVIDUAL JSON OBJECT FROM JSON ARRAY
                                        JSONObject jo = joRespond.getJSONObject(i);
                                        courses.add(jo.getString("Course_id"));
                                    }
                                    textView.setText("");
                                    selectedSection="";
                                    sections=new ArrayList<>();
                                    CoursesAdapter = new ArrayAdapter<String>(AddSchedule.this, android.R.layout.simple_spinner_item, courses);
                                    CoursesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
                                    CoursesSpinner.setAdapter(CoursesAdapter);

                                    Util.dismissprogress();
                                } catch (Exception e) {
                                    Util.dismissprogress();
                                    e.printStackTrace();
                                }
                            }


                        });

                        Util.dismissprogress();
                    }


                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    Log.d("my4Tag", "W2");

                    levelSpinner.setSelection(0);
                }
            });
            ///courses spinner


            CoursesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i != 0) {
                        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                        RequestParams params = new RequestParams();
                        params.put("operation", "getsection");
                        params.put("course", courses.get(i));
                        asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                            @Override
                            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                                Util.dismissprogress();

                            }

                            @Override
                            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                                Util.dismissprogress();
                                Log.e("salama", "onSuccess: " + responseString);
                                try {
                                    sections=new ArrayList<>();
                                    JSONObject jsonObject = new JSONObject(responseString);
                                    if (!jsonObject.getBoolean("error")) {
                                        JSONArray jsonObject1 = jsonObject.getJSONArray("message");
                                        int n = jsonObject1.length();
                                        for (int i = 0; i < n; i++) {
                                            // GET INDIVIDUAL JSON OBJECT FROM JSON ARRAY
                                            Section section_obj = new Section();
                                            JSONArray jsonArray = jsonObject1.getJSONArray(i);

                                            section_obj.setId(jsonArray.get(0)+"");
                                            section_obj.setSection_name(jsonArray.get(1)+"");
                                            section_obj.setDays(jsonArray.get(3)+"");
                                            section_obj.setSection_time(jsonArray.get(4)+"");

                                            sections.add(section_obj);
                                        }

                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                textView.setText("");
                                selectedSection="";
                                SectionAdapter = new ArrayAdapter<Section>(AddSchedule.this, android.R.layout.simple_spinner_item, sections);
                                SectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
                                SectionSpinner.setAdapter(SectionAdapter);
                            }


                        });
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });
            //Section Spinner


            SectionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                    Section section = sections.get(i);
                    textView.setText(section.getDays() + "\n" + section.getSection_time());
                    selectedSection = "" + section.getId();
                    //section_obj.setSection_time(Section_time);
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    textView.setText("");
                    selectedSection="";
                    SectionSpinner.setSelection(0);
                }
            });

        } catch (Exception e) {

        }

    }

    public ArrayList getC() {
        return db.getAllCorses();
    }

    public void setC(ArrayList c) {
        this.c = c;
    }

    public void back_to_login(View v) {
        ImageButton button2 = (ImageButton) v;
        startActivity(new Intent(AddSchedule.this, LoginActivity.class));
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add) {
            Intent intent1 = new Intent(this, AddSchedule.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.edit) {
            Intent intent1 = new Intent(this, RemoveSchedule.class);
            intent1.putExtra("update", true);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.annou) {
            Intent intent1 = new Intent(this, AnnListActivity.class);
            this.startActivity(intent1);
            return true;
        }if (id == R.id.gen) {
            GeneTableActivity.admin=0;
            Intent intent1 = new Intent(this, GeneTableActivity.class);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.logout) {
            Intent intent1 = new Intent(this, MainActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        return false;
    }
}
