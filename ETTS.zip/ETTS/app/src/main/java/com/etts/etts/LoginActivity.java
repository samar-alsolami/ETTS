package com.etts.etts;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.etts.etts.admin.SemesterInformation;
import com.etts.etts.student.AddSchedule;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;


public class LoginActivity extends AppCompatActivity {
    DB_Connection connect;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        connect = new DB_Connection(this);
    }

    //move to main page
    public void back_to_main(View v) {
        Button back_butt = (Button) v;
        startActivity(new Intent(LoginActivity.this, MainActivity.class));
    }

    //
    public void login(View v) {

        if (v.getId() == R.id.login_butt) {
            EditText username = (EditText) findViewById(R.id.username);
            String namestr = username.getText().toString();

            EditText password = (EditText) findViewById(R.id.password);
            String passstr = password.getText().toString();
//            namestr="administrator";
//            namestr="1605434";
//            passstr="1605434";
            try {
                Log.d("my3Tag", "M1");

                if (namestr.equals("administrator") && passstr.equals("123456")) {
                    Intent i = new Intent(LoginActivity.this, SemesterInformation.class);
                    startActivity(i);
                } else {
                    Log.d("my3Tag", "M2");


                    AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                    RequestParams params = new RequestParams();
                    params.put("operation", "login");
                    params.put("username", namestr);
                    params.put("password", passstr);
                    Util.showprogress(LoginActivity.this, "Log in ...");
                    asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                            Util.dismissprogress();
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            try {
                                Log.e("Salama", "onSuccess: " + responseString);
                                JSONObject jsonObject = new JSONObject(responseString);
                                if (!jsonObject.getBoolean("error")) {
                                    JSONObject jsonObject1 = jsonObject.getJSONObject("message");
                                    Constant.user_name = jsonObject1.getString("UserName");
                                    Constant.email = jsonObject1.getString("Email");
                                    Intent i = new Intent(LoginActivity.this, AddSchedule.class);
                                    i.putExtra("Username", Constant.user_name);
                                    startActivity(i);
                                } else {
                                    Toast pass = Toast.makeText(LoginActivity.this, "username or password not correct , try again", Toast.LENGTH_SHORT);
                                    pass.show();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            Util.dismissprogress();
                        }


                    });

                    Util.dismissprogress();


                }
            } catch (Exception e) {
                Log.d("my3Tag", e.getMessage());
            }


        }
    }

}
