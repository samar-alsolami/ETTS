package com.etts.etts.admin;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.etts.etts.Constant;
import com.etts.etts.MainActivity;
import com.etts.etts.R;
import com.etts.etts.Util;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import java.text.SimpleDateFormat;
import java.util.Date;

import cz.msebera.android.httpclient.Header;

public class AnnActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    EditText ann;
    Button send, cancel;
    private DrawerLayout mdrawerlayout;
    private ActionBarDrawerToggle mtoggle;
    NavigationView navigationView;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mtoggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ann);
        mdrawerlayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        navigationView = (NavigationView) findViewById(R.id.navigation);


        //menu
        mtoggle = new ActionBarDrawerToggle(this, mdrawerlayout, R.string.open, R.string.close);
        mdrawerlayout.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(this);

        ann = findViewById(R.id.ann);
        send = findViewById(R.id.send);
        cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ann.setText("");
                finish();
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy mm:ss");
                AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                RequestParams params = new RequestParams();
                params.put("operation", "addann");
                params.put("anndate", simpleDateFormat.format(new Date()));
                params.put("announcement", ann.getText().toString());
                if(ann.getText()!=null&&! ann.getText().toString().isEmpty()){
                    asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                            Util.dismissprogress();
                            Toast.makeText(AnnActivity.this, "error", Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            ann.setText("");
                            Util.dismissprogress();
                            Toast.makeText(AnnActivity.this, "Send ", Toast.LENGTH_SHORT).show();
                        }


                    });
                }else{
                    Toast.makeText(AnnActivity.this, "enter message first", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.edit) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.putExtra("update", true);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.annou) {
            Intent intent1 = new Intent(this, AnnActivity.class);
            this.startActivity(intent1);
            return true;
        }

        if (id == R.id.exam) {
            Intent intent1 = new Intent(this, FinalExamActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if(id==R.id.gen){
            GeneTableActivity.admin=1;
            AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
            RequestParams params = new RequestParams();
            asyncHttpClient.post(Constant.GENERATE, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            Intent intent1 = new Intent(AnnActivity.this, GeneTableActivity.class);
                            AnnActivity.this.startActivity(intent1);

                        }
                    }
            );
            return true;
        }
        if (id == R.id.logout) {
            Intent intent1 = new Intent(this, MainActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        return false;
    }
}
