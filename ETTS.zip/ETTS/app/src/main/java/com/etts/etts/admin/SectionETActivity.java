package com.etts.etts.admin;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.etts.etts.Constant;
import com.etts.etts.MainActivity;
import com.etts.etts.R;
import com.etts.etts.Util;
import com.etts.etts.bean.Section;
import com.etts.etts.student.RemoveSchedule;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class SectionETActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout mdrawerlayout;
    private ActionBarDrawerToggle mtoggle;
    NavigationView navigationView;

    ArrayList<Section> sections = new ArrayList<>();
    CustomAdapter adapter;
    ListView listView;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mtoggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /////
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_section_et);
        mdrawerlayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        navigationView = (NavigationView) findViewById(R.id.navigation);


        //menu
        mtoggle = new ActionBarDrawerToggle(this, mdrawerlayout, R.string.open, R.string.close);
        mdrawerlayout.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(this);

        //////


        listView=(ListView)findViewById(R.id.list);


        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("operation", "getsection");
        params.put("admin","admin");
        asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                Util.dismissprogress();

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                Util.dismissprogress();
                Log.e("salama", "onSuccess: " + responseString);
                try {
                    sections = new ArrayList<>();
                    JSONObject jsonObject = new JSONObject(responseString);
                    if (!jsonObject.getBoolean("error")) {
                        JSONArray jsonObject1 = jsonObject.getJSONArray("message");
                        int n = jsonObject1.length();
                        for (int i = 0; i < n; i++) {
                            // GET INDIVIDUAL JSON OBJECT FROM JSON ARRAY
                            Section section_obj = new Section();
                            JSONArray jsonArray = jsonObject1.getJSONArray(i);

                            section_obj.setId(jsonArray.get(0) + "");
                            section_obj.setSection_name(jsonArray.get(1) + "");
                            section_obj.setCourse_id(jsonArray.get(2) + "");
                            section_obj.setDays(jsonArray.get(3) + "");
                            section_obj.setSection_time(jsonArray.get(4) + "");
                            section_obj.setNumber(jsonArray.get(5)+"" );

                            sections.add(section_obj);
                        }

                    }

                    adapter= new CustomAdapter(sections,SectionETActivity.this);

                    listView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }


        });

    }

    //for menu



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.edit) {
            Intent intent1 = new Intent(this, SemesterInformation.class);
            intent1.putExtra("update", true);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if (id == R.id.annou) {
            Intent intent1 = new Intent(this, AnnActivity.class);
            this.startActivity(intent1);
            return true;
        }

        if (id == R.id.exam) {
            Intent intent1 = new Intent(this, FinalExamActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        if(id==R.id.gen){
            GeneTableActivity.admin=1;
            AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
            RequestParams params = new RequestParams();
            asyncHttpClient.post(Constant.GENERATE, params, new TextHttpResponseHandler() {
                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            Intent intent1 = new Intent(SectionETActivity.this, GeneTableActivity.class);
                            SectionETActivity.this.startActivity(intent1);

                        }
                    }
            );
            return true;
        }
        if (id == R.id.logout) {
            Intent intent1 = new Intent(this, MainActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            this.startActivity(intent1);
            return true;
        }
        return false;
    }
}



