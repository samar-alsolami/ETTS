package com.etts.etts.student;

import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.etts.etts.Constant;
import com.etts.etts.R;
import com.etts.etts.bean.Section;
import com.etts.etts.Util;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class AnnListActivity extends ListActivity {
    private TextView text;
    private List<String> listValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ann_list);
        text = (TextView) findViewById(R.id.mainText);

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("operation", "listann");
        asyncHttpClient.post(Constant.HOME, params, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

                Util.dismissprogress();

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                Util.dismissprogress();
                Log.e("salama", "onSuccess: " + responseString);
                try {
                    listValues = new ArrayList<>();
                    JSONObject jsonObject = new JSONObject(responseString);
                    if (!jsonObject.getBoolean("error")) {
                        JSONArray jsonObject1 = jsonObject.getJSONArray("message");
                        int n = jsonObject1.length();
                        for (int i = 0; i < n; i++) {
                            // GET INDIVIDUAL JSON OBJECT FROM JSON ARRAY
                            Section section_obj = new Section();
                            JSONArray jsonArray = jsonObject1.getJSONArray(i);



                            listValues.add(jsonArray.get(1) + "\n"+jsonArray.get(2));
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                ArrayAdapter<String> myAdapter = new ArrayAdapter <String>(AnnListActivity.this,
                        R.layout.row_layout, R.id.listText, listValues);

                // assign the list adapter
                setListAdapter(myAdapter);
            }


        });

        // initiate the listadapter


    }

    // when an item of the list is clicked
    @Override
    protected void onListItemClick(ListView list, View view, int position, long id) {
        super.onListItemClick(list, view, position, id);

        String selectedItem = (String) getListView().getItemAtPosition(position);
        //String selectedItem = (String) getListAdapter().getItem(position);

        text.setText("You clicked " + selectedItem + " at position " + position);
    }

}